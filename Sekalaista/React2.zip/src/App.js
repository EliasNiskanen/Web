import logo from './logo.svg';
import './App.css';

import Table from './TableClass';


function App() {
  const nimi = "Noora"; //tämä on kommentti
  const list = ["Minä", "Sinä", "Hän"]
  return (
    <div className="App">
   
     <Table/>
  
    </div>
  );
}

export default App;
