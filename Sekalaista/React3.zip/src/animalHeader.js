import { Component } from "react";


class animalHeader extends Component{
render(){
return(
<table className="table">  
    <th>Name</th>
    <th>Owner</th>
    <th>Year</th>
    <th>Breed</th>
</table>
  
)

}
}

export default animalHeader;