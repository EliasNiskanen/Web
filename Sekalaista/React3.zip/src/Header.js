import { Component } from "react";


class Header extends Component{
render(){
return(
<table className="table">  
    <th>Name</th>
    <th>Address</th>
    <th>Year</th>
</table>
  
)

}
}

export default Header;