import logo from './logo.svg';
import './App.css';
import Table from './TableClass';
import Header from './Header';
import animalTable from './Animaltable';
import animalHeader from './animalHeader';

//Toinen taulukko kyllä olevinaan tulee mutta sisältöä ei vain tullut näkyviin vaikka miten väänsi
function App() {
  return (
    <div>

    <div className="App">
      <div><h1>Tämä on ensimmäinen taulukko</h1></div>
   <Header/>
     <Table/>
     </div>


     <div className="App">
     <div><h1>Tämä on toinen taulukko</h1></div>
     <animalHeader/>
      <animalTable/>
      </div>

    </div>
    
  );
}


export default App;
