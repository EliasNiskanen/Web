import logo from './logo.svg';
import './App.css';
import Nappi from './Nappi';
import Elainlista from './Elainlista';
import DataTable from './DataTable'

function App() {
  return (
    <div className="App">
      <Elainlista/>
      <Nappi/>
      <DataTable/>
    </div>
  );
}

export default App;
